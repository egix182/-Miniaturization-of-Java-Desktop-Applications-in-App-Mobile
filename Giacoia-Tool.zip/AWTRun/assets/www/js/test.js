var awtPlugin = {
		fire: function(id,successCallback, errorCallback) {
	    cordova.exec(
	        successCallback,
	        errorCallback,
	        'AWTPlugin', 
	        'fire',
	        [{
	        	"id": id
	        }]
	    );
	 },

	insert: function(id,a,successCallback, errorCallback) {
	    cordova.exec(
	        successCallback,
	        errorCallback,
	        'AWTPlugin',
	        'insert',
	        [{
	         "id": id,
	         "element": a
	        }]
	    );
	 },
	 
	 fireRow: function(id, row, successCallback, errorCallback) {
	    cordova.exec(
	        successCallback,
	        errorCallback,
	        'AWTPlugin',
	        'fireRow',
	        [{
	         "id": id,
	         "row": row
	        }]
	    );
	 },
	 
	 fireCell: function(id, row, column, successCallback, errorCallback) {
	    cordova.exec(
	        successCallback,
	        errorCallback,
	        'AWTPlugin',
	        'fireCell',
	        [{
	         "id": id,
	         "row": row,
                 "column": column
	        }]
	    );
	 },
	 
	 insertTable: function(id, row, column, value, successCallback, errorCallback) {
	    cordova.exec(
	        successCallback,
	        errorCallback,
	        'AWTPlugin',
	        'insertTable',
	        [{
	         "id": id,
	         "row": row,
                 "column": column, 
                 "value": value
	        }]
	    );
	 }
};
