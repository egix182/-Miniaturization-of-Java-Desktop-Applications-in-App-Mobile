package mini;

import java.util.Vector;


import table.DefaultTableModel;

import awtcalc2pg.ActionEvent;
import awtcalc2pg.ActionListener;
import awtcalc2pg.pButton;
import awtcalc2pg.pComponent;
import awtcalc2pg.pFrame;
import awtcalc2pg.pLabel;
import awtcalc2pg.pMenuBar;
import awtcalc2pg.pPanel;
import awtcalc2pg.pTable;


public class SwapTeam_pawt {
	private pFrame mainFrame;
	private pTable table0;
	private pTable table1;
	private DefaultTableModel model0; 
	private DefaultTableModel model1; 
	private pLabel squadra0;
	private pLabel squadra1;
	private pButton s0TOs1;
	private pButton s1TOs0;
	private pMenuBar barraMenu = new pMenuBar();
	
	public SwapTeam_pawt()
	{
		squadra0 = new pLabel("Juventus");
		squadra1 = new pLabel("Milan");
		String[] columnName = {"Nome", "Cognome"};
		Object[][] dataS0 = {
				{"Alessandro", "Del Piero"},
				{"Gianluca", "Zambrotta"},
				{"Gianluigi", "Buffon"},
		};
		Object[][] dataS1 = {
				{"Filippo", "Inzaghi"},
				{"Andrea", "Pirlo"},
				{"Paolo", "Maldini"},
		};
		
		s0TOs1 = new pButton(">>");
		s1TOs0 = new pButton("<<");
			
		mainFrame = new pFrame("Java pAWT SwapTeam");
		mainFrame.setMenuBar(barraMenu);
		
		pPanel panelS0 = new pPanel();
		model0 = new DefaultTableModel(dataS0,columnName);
		table0 = new pTable(model0);
		/*JPanel panelT0 = new JPanel();
		panelT0.setLayout(new BorderLayout());
		panelT0.add(table0.getTableHeader(), BorderLayout.PAGE_START);
		panelT0.add(table0, BorderLayout.CENTER);*/
		table0.setForeground("WHITE");
		table0.setGridColor("WHITE");
		table0.setBackground("BLACK");
		table0.setRowHeight(60);
		table0.setIntercellSpacing(10,0);
		panelS0.add(squadra0);
		panelS0.add(table0); //panelS0.add(panelT0);
		panelS0.add(s0TOs1);
		mainFrame.add(panelS0);
		
		pPanel panelS1 = new pPanel();
		model1 = new DefaultTableModel(dataS1,columnName);
		table1 = new pTable(model1);
		/*JPanel panelT1 = new JPanel();
		panelT1.setLayout(new BorderLayout());
		panelT1.add(table1.getTableHeader(), BorderLayout.PAGE_START);
		panelT1.add(table1, BorderLayout.CENTER);*/
		table1.setForeground("RED");
		table1.setGridColor("RED");
		table1.setBackground("BLACK");
		table1.setRowHeight(60);
		table1.setIntercellSpacing(10,0);
		panelS1.add(s1TOs0);
		panelS1.add(table1);//panelS1.add(panelT1);
		panelS1.add(squadra1);
		mainFrame.add(panelS1);
		
		model0.addTableModelListener(table0);
		model1.addTableModelListener(table1);
		/*mainFrame.setLayout(new FlowLayout());
		mainFrame.pack();
		mainFrame.setVisible(true);*/
		
		s0TOs1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] rows = table0.getSelectedRows();
				for(int i: rows){
					Vector v = (Vector) model0.getDataVector().elementAt(i);
					model1.addRow((Vector)v.clone());
					model0.removeRow(i);
				}
			}
		});
		
		s1TOs0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] rows = table1.getSelectedRows();
				for(int i: rows){
					Vector v = (Vector) model1.getDataVector().elementAt(i);
					model0.addRow((Vector)v.clone());
					model1.removeRow(i);
				}
			}
		});
	}
	
	public pFrame getTopComponent(){
		return mainFrame;
	}
	
	/*public static void main(String[] arg)
	{
		new SwapTeam_pawt();
	}*/

}
