package awtcalc2pg;

public class pLabel extends pComponent{
	
	ActionListener _actionListener;
	pComponent _root;
	
	public pLabel(String title){
		_title = title;
	}
	
	public void addActionListener(ActionListener actionListener) {
		 this._actionListener = actionListener;
		
	}
	
	public void fire() {
		if(_actionListener != null){
			this._actionListener.actionPerformed(new ActionEvent(this, _title));
		}
	}

	public void setRoot(pComponent root){
		this._root = root;
	}
	
	public void create() {
		parserHTML.addLabel(_title);
	}
	
	public void setText(String value) {
		/*
		if(!value.equals(_value)) {
			_value = value;
				try {
					CordovaWebView wv = Constants.view;
					if(wv != null){
						wv.sendJavascript("app.setta('"+_title+"','"+_value+"')");
				//Log.d("sono in if", "appsetta : " + _title);
						}	
				} catch(Exception e) {}
			}	
		
		 */
	}
	
}