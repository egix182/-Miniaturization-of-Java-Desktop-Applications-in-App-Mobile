package awtcalc2pg;


public class pButton extends pComponent{
	ActionListener _actionListener;
	pComponent _root;
	
	public pButton(String title){
		_title = title;
	}
	
	public void addActionListener(ActionListener actionListener) {
		 this._actionListener = actionListener;
		
	}
	
	public void fire() {
		if(_actionListener != null){
			this._actionListener.actionPerformed(new ActionEvent(this, _title));
		}
	}

	public void setRoot(pComponent root){
		this._root = root;
	}
	
	public void create() {
		parserHTML.addButton(_title);
	}

}
