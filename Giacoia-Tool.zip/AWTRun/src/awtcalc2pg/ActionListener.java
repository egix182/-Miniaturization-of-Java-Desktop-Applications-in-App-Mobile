package awtcalc2pg;
import java.util.EventObject;


public interface ActionListener {
	
	public void actionPerformed(ActionEvent e);

}
