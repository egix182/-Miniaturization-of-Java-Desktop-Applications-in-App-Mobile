package awtcalc2pg;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * Created by ALFREDO on 25/02/2017.
 */


public class pMenu extends pComponent {

    ArrayList<pMenuItem> array_menu = new ArrayList<pMenuItem>();

    public pMenu(String title){
        _title = title;
    }

    public void add(pMenuItem pMenuItem){
        array_menu.add(pMenuItem);
    }

    public ArrayList<pMenuItem> getArray_menu() {
        return array_menu;
    }

    public boolean has_item(){

        return !array_menu.isEmpty();
    }
}