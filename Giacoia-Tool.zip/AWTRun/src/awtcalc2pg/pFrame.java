package awtcalc2pg;

import java.util.ArrayList;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Map;
import java.util.Map.Entry;

import android.util.Log;

import java.util.Set;
import java.util.Vector;

import awtcalc2pg.ActionEvent;
import awtcalc2pg.ActionListener;
import awtcalc2pg.pTextField;
import table.DefaultTableModel;

class Repository {

    Hashtable<String, pComponent> components = new Hashtable<String, pComponent>();

    public void addComponent(String key, pComponent component) {
    	components.put(key, component);
    }
    
    private pComponent find(String key){
        Set<Entry<String, pComponent>> entrySet = components.entrySet();
        Iterator iterator = entrySet.iterator();
        while(iterator.hasNext()){
            Entry<String, pComponent> entry = (Entry<String, pComponent>) iterator.next();
            if(entry.getValue() instanceof pPanel){
                pPanel panel = (pPanel) entry.getValue();
                pComponent toReturn = panel.rep.find(key);
                if(toReturn != null) {
                    return toReturn;
                }
            } else if(entry.getKey().equals(key)){
                return entry.getValue();
            }
        }
        return null;
    }

    public  void click(String key) {
        pComponent component = find(key);
        if(component != null){
            component.fire();
        }
    }

    public void change(String key, String value) {
        pComponent component = find(key);
        if(component != null && component instanceof pTextField){
            pTextField f = (pTextField)component;
            f.setText(value);
        }
    }
    
    public void fireRow(String key, String posRow) {
        pComponent component = find(key);
        if(component != null && component instanceof pTable){
            pTable t = (pTable)component;
            if(t.getRowSelectionAllowed()){
            	t.setRowSelectionInterval(Integer.parseInt(posRow), Integer.parseInt(posRow));
            }
        }
    }
    
   
    
    public void fireCell(String key, String posRow, String posColumn) {
        pComponent component = find(key);
        if(component != null && component instanceof pTable){
            pTable t = (pTable)component;
           if(t.isCellEditable(Integer.parseInt(posRow), Integer.parseInt(posColumn))){
            	t.editCellAt(Integer.parseInt(posRow), Integer.parseInt(posColumn));
            }
        }
    }
    
    public void change(String key, String posRow, String posColumn, String value) {
        pComponent component = find(key);
        if(component != null && component instanceof pTable){
        	pTable t = (pTable)component;
        	t.getModel().setValueAt(value, Integer.parseInt(posRow),(Integer.parseInt(posColumn)));
        }
    }
    
}

public class pFrame extends pComponent{
    Repository rep = new Repository();
    ActionListener _actionListener;
    pMenuBar menu;

    public pFrame(String title){
        _title = title;
        menu = null;
    }
    
    public void setMenuBar(pMenuBar menuBar){

        this.menu = menuBar;
        parse_menu(menuBar.getArray_menu());
    }
    

    public void parse_menu(ArrayList<pMenu> bar){
        int i;

        for(i=0;i<bar.size();i++){

            this.add(bar.get(i));
            if(bar.get(i).has_item())
                parse_menu_item(bar.get(i).getArray_menu());
        }
    }


    private  void parse_menu_item(ArrayList<pMenuItem> pmenui){
        int i;
        for(i=0;i<pmenui.size();i++){
            this.add(pmenui.get(i));
            if(pmenui.get(i).has_item())
                parse_menu_item(pmenui.get(i).getArray_menu());
        }
    }
    
    public void setSize(int x,int y) {}

    public void add(pComponent c) {
        c.setRoot(this);
        rep.addComponent(c._title, c );
    }
    
    public ArrayList<pComponent> getComponents(){
    	ArrayList<pComponent> components = new ArrayList<pComponent>();
    	Set<Entry<String, pComponent>> entrySet = rep.components.entrySet();
    	Iterator i = entrySet.iterator();
    	
    	while(i.hasNext()) 
    		components.add(((Entry<String, pComponent>) i.next()).getValue());
    	return components;
    }

    public void addActionListener(ActionListener actionListener) {
        this._actionListener = actionListener;
    }

    public void fire() {
        if(_actionListener != null){
            this._actionListener.actionPerformed(new ActionEvent(this, this._title));
        }
    }

    public void fire(String dest) {
        rep.click(dest);
    }

    public void change(String dest, String value) {
        rep.change(dest,value);
    }

	public void fireRow(String id, String row) {
		rep.fireRow(id,row);
		
	}

	public void fireCell(String id, String row, String column) {
		rep.fireCell(id,row, column);
		
	}

	public void change(String id, String row, String column, String value) {
		rep.change(id, row, column, value);
	}
}
