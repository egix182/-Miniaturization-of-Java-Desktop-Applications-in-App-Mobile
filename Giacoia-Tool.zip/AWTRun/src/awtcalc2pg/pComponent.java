package awtcalc2pg;


import awtcalc2pg.ActionListener;

public abstract class pComponent {
	
	String _title;
	pComponent _root;
	
	
	public void create() {}	
    
	public void addActionListener(ActionListener actionListener) {}
	
	public void fire() {}
	
	public void fire(String dest){}


	//nuovi metodi aggiunti
    public void setRoot(pComponent root){}
	public void requestFocus() {}
	public String getName(){ return _title; }

	
}
