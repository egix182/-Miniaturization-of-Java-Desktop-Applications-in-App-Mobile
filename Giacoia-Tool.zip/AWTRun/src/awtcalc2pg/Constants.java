package awtcalc2pg;

import org.apache.cordova.CordovaWebView;

public class Constants {
	public static boolean generation = true;
	public static CordovaWebView view;
}
