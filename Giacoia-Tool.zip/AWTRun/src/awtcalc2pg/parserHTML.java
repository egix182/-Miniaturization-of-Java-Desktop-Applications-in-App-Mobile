package awtcalc2pg;


import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Set;

import javax.xml.parsers.*;
import javax.xml.transform.*;
import javax.xml.transform.dom.DOMSource;
import javax.xml.transform.stream.StreamResult;

import org.w3c.dom.Document;
import org.w3c.dom.Element;


public class parserHTML {
	private static Document doc;
	private static Element head;
	private static Element body;
	private static HashMap<String, Element> frames = new HashMap<String, Element>();
	private static HashMap<String, Element> elements = new HashMap<String, Element>();
	private static Set<Set<String>> _partition;
	public static String buttonEvent="app.fire(id)";
	public static String textEvent="app.insert(id,document.getElementById(id).value)";
	private static Element tag_div;
	private static Element span_menu;
	
	public static String rowEvent="app.fireRow(id)";
	public static String cellFireEvent="app.fireCell(id)";
	public static String cellInsertEvent="app.insertTable(id)";
	public static String tableCSS = "css/tableCSS.css";
	public static PrintWriter pw;
	
	public parserHTML(){
	
	}
	
	public static void addmenu(ArrayList<pMenu> bar){
					
			tag_div = doc.createElement("div");
			body.appendChild(tag_div);
			tag_div.setAttribute("id", "myNav");
			tag_div.setAttribute("class", "frame overlay");
			
			
			Element a = doc.createElement("a");
			a.appendChild(doc.createTextNode("x"));
			tag_div.appendChild(a);
			a.setAttribute("href", "javascript:void(0)");
			a.setAttribute("class", "closebtn");
			a.setAttribute("onclick", "closeNav()");
			
			
			span_menu = doc.createElement("span");
			span_menu.setAttribute("class", "overlay-content");
			
			tag_div.appendChild(span_menu);
			
			//Element li = doc.createElement("li");
			//ul.appendChild(li);
			
			parse_menu(bar);
			
			/*
				Element viewport = doc.createElement("META");
				viewport.setAttribute("name", "viewport");
				viewport.setAttribute("content", "user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height, target-densitydpi=device-dpi");
				head.appendChild(viewport);
								
				body = doc.createElement("BODY");
				body.setAttribute("onhashchange", "updateFooter();");
				body.setAttribute("onload", "defaultFrame();");
				rootElement.appendChild(body);
			*/
			
	}
	
	
	public static void parse_menu(ArrayList<pMenu> bar){
		int i;
		
		
		Element ul = doc.createElement("ul"); //System.out.println("<ul>"); 
		span_menu.appendChild(ul);
		for(i=0;i<bar.size();i++){
				
				Element li = doc.createElement("li"); //System.out.println("<li>"); 
				ul.appendChild(li);
				li.appendChild(doc.createTextNode("- " + bar.get(i).getName()  + ": "));
				li.setAttribute("onclick", "insert_menu(this)");
				li.setAttribute("class", "colorMenu");
				li.setAttribute("style", "color: #ecf503;");
				//System.out.println(); 
				if(bar.get(i).has_item())
					parse_menu_item(li, bar.get(i).getArray_menu());
				
				//System.out.println("</li>");	
		}
		//System.out.println("</ul>"); 
	}
	
	
	private static void parse_menu_item(Element tag_li, ArrayList<pMenuItem> pmenui){
		int i;
	
		Element ul = doc.createElement("ul"); //System.out.println("<ul>"); 
		tag_li.appendChild(ul);
		ul.setAttribute("hidden", "true");
		for(i=0;i<pmenui.size();i++){
				
				Element li = doc.createElement("li"); //System.out.println("<li>"); 
				ul.appendChild(li);
				li.appendChild(doc.createTextNode(pmenui.get(i).getName()) ); //System.out.println(pmenui.get(i).getName());
				li.setAttribute("id", pmenui.get(i).getName() );	
				li.setAttribute("onclick", "app.fire(id)");
				li.setAttribute("class", "subnav");
				if(pmenui.get(i).has_item())
					parse_menu_item(li, pmenui.get(i).getArray_menu());
				
				//System.out.println("</li>"); 
				
		}
		//System.out.println("</ul>"); 
	}
	
	
	public static void parse(pComponent c){
		
		if(c instanceof pFrame){
			for(pComponent component : ((pFrame) c).getComponents()) //tutti i pComponent del pFrame
				parse(component);
		} else if(c instanceof pPanel){ //AGGIUNGO I PANNELLI, con all'interno i pComponent
			for(pComponent component : ((pPanel) c).getComponents())
				parse(component);
		}else{
			
			if((c instanceof pMenuBar)||(c instanceof pMenuItem)||(c instanceof pMenu)){
				return;
			}
			
			System.out.println("creating: "+c.getName());
			c.create(); //chiamo il metodo create di ogni pComponent dell'applicazione. 
		}
	}
	
	public static void createPage(String title, Set<Set<String>> partition){
		try {
			DocumentBuilderFactory docFactory = DocumentBuilderFactory.newInstance();
			DocumentBuilder docBuilder = docFactory.newDocumentBuilder();
			doc = docBuilder.newDocument();
			Element rootElement = doc.createElement("HTML");
			head = doc.createElement("HEAD");
			doc.appendChild(rootElement);
			addCss("css/index.css");
			addCss("css/ionic.css");
			addCss("css/ionicons.min.css");
			addCss("css/menu/menulaterale.css");
			
			//table
			addCss(tableCSS);
			
			
			rootElement.appendChild(head);
			
			Element viewport = doc.createElement("META");
			viewport.setAttribute("name", "viewport");
			viewport.setAttribute("content", "user-scalable=no, initial-scale=1, maximum-scale=1, minimum-scale=1, width=device-width, height=device-height, target-densitydpi=device-dpi");
			head.appendChild(viewport);
			
			
			Element title1 = doc.createElement("TITLE");
			title1.appendChild(doc.createTextNode(title));
			head.appendChild(title1);
			
			body = doc.createElement("BODY");
			body.setAttribute("onhashchange", "updateFooter();");
			body.setAttribute("onload", "defaultFrame();");
			rootElement.appendChild(body);
			_partition = partition;
			
			//table
			File f = new File(tableCSS);
			if(f.exists()) f.delete();
		
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
		}
	}
	
	public static Element addFrame(String title){
		Element frame = doc.createElement("DIV");
		frame.setAttribute("id", title);
		frame.setAttribute("class", "frame");
		
		Element div_menu = doc.createElement("div");
		frame.appendChild(div_menu);
		div_menu.setAttribute("class", "scritta_menu");
		div_menu.setAttribute("onclick", "openNav()");
		div_menu.appendChild(doc.createTextNode("||| MENU"));
		return frame;
	}
	
	public static void addHeader(String title){
		Element header = doc.createElement("DIV");
		header.setAttribute("id", "title");
		header.setAttribute("class", "bar bar-header bar-positive");
		
		Element h1 = doc.createElement("H1");
		h1.setAttribute("class", "title");
		
		h1.appendChild(doc.createTextNode(title));
		header.appendChild(h1);
		body.appendChild(header);
	}
	
	private static void addFooter(){
		Element footer = doc.createElement("DIV");
		Element framesBullets = doc.createElement("DIV");
		Element buttonLeft = doc.createElement("BUTTON");
		Element buttonRight = doc.createElement("BUTTON");
		footer.setAttribute("id", "footer");
		buttonLeft.setAttribute("id","buttonLeft");
		buttonRight.setAttribute("id","buttonRight");
		framesBullets.setAttribute("id", "framesBullets");
		framesBullets.setAttribute("class", "title" );
		footer.setAttribute("class", "bar bar-positive bar-footer");
		buttonLeft.setAttribute("class", "hide button button-clear icon-left ion-android-arrow-dropleft-circle");
		buttonRight.setAttribute("class", "hide button button-clear icon-right ion-android-arrow-dropright-circle");
		footer.appendChild(buttonLeft);
		footer.appendChild(framesBullets);
		footer.appendChild(buttonRight);
		body.appendChild(footer);
	}

	private static void addScript(String path){
		Element script= doc.createElement("SCRIPT");
		script.setAttribute("type", "text/javascript");
		script.setAttribute("src", path);
		body.appendChild(script);
	}

	private static void addCss(String path){
		Element css = doc.createElement("LINK");
		css.setAttribute("rel", "stylesheet");
		css.setAttribute("type", "text/css");
		css.setAttribute("href", path);
		head.appendChild(css);
		
	}
	
	public static void addButton(String name){
		Element button = doc.createElement("BUTTON");
		button.setAttribute("type", "button");
		button.setAttribute("class", "button");
		button.setAttribute("id", name);
		button.appendChild(doc.createTextNode(name));
		button.setAttribute("onClick", buttonEvent);
		elements.put(name, button);
	}
	
	public static void addLabel(String name){
		Element list = doc.createElement("DIV");
		
		Element label = doc.createElement("LABEL");
		
		label.setAttribute("id", name);
		label.setAttribute("class", "label");
		
		label.appendChild(doc.createTextNode(name));
		list.appendChild(label);
		elements.put(name, list);
	}
	
	
	public static void addRadioButton(String name) {
		
		System.out.println("Radio button creato");
		Element button = doc.createElement("INPUT");
        button.setAttribute("type", "radio");
        button.setAttribute("name", "name");
        button.setAttribute("value", "value");
        button.setAttribute("id", name);
        button.appendChild(doc.createTextNode(name));
        button.setAttribute("onClick", buttonEvent);
        elements.put(name, button);
    }
	
	
	public static void addTextField(int size, String title){
		Element list = doc.createElement("DIV");
		list.setAttribute("class", "areaditesto");
		Element label = doc.createElement("LABEL");
		Element textField = doc.createElement("INPUT");
				
		textField.setAttribute("type", "text");
		textField.setAttribute("placeholder", title);
		textField.setAttribute("id", title);
		textField.setAttribute("onkeyup", textEvent);
		
		label.appendChild(textField);
		list.appendChild(label);
		elements.put(title, list);
	}
	
	//Table
		public static void addTable(String title, pTable table){
			Element divHTML = doc.createElement("DIV");
			divHTML.setAttribute("class", "divTab");
			Element tableHTML = doc.createElement("TABLE");
			tableHTML.setAttribute("id", title);
			tableHTML.setAttribute("class", "tab");
			tableHTML.setAttribute("border", "1");
			create_headerTable(tableHTML, table);
			create_rows(tableHTML, table);
			create_tableCSS(table, title);
			divHTML.appendChild(tableHTML);
			elements.put(title, divHTML);
		}

		private static void create_tableCSS(pTable table, String title)
		{
			try {
				File f = new File(tableCSS);
				FileOutputStream fos = new FileOutputStream(f, true);
				if(!f.exists())
				{	
					f.createNewFile();
				}
				pw = new PrintWriter(fos);
				
				//table
				writeCssProperty("#"+table._title,"border-collapse", "collapse");
				writeCssProperty("#"+table._title,"width", "100%");
				writeCssProperty("."+table._title+"-column", "color", table.foreground);
				writeCssProperty("."+table._title+"-column", "border-color", table.gridColor);
				writeCssProperty("."+ table._title+"-column", "background-color", table.background);
				writeCssProperty("."+ table._title+"-row", "height", ""+table.getRowHeight()+"px");
				writeCssProperty("."+table._title+"-column", "border-width", "1px");
				writeCssProperty("."+table._title+"-column", "border-style", "solid");
				writeCssProperty("."+table._title+"-column", "padding-top", ""+table.getRowMargin()+"px");
				writeCssProperty("."+table._title+"-column", "padding-bottom", ""+table.getRowMargin()+"px");
				writeCssProperty("."+table._title+"-column", "padding-left", ""+table.getColumnModel().getColumnMargin()+"px");
				writeCssProperty("."+table._title+"-column", "padding-right", ""+table.getColumnModel().getColumnMargin()+"px");

				//table-select
				writeCssProperty("."+table._title+"-column-selected", "border-width", "1px");
				writeCssProperty("."+table._title+"-column-selected", "border-style", "solid");
				writeCssProperty("."+table._title+"-column-selected", "color", table.selectionForeground);
				writeCssProperty("."+table._title+"-column-selected", "border-color", table.gridColor);
				writeCssProperty("."+ table._title+"-column-selected", "background-color", table.selectionBackground);
				writeCssProperty("."+ table._title+"-row-selected", "height", ""+table.getRowHeight()+"px");
				writeCssProperty("."+table._title+"-column-selected", "padding-top", ""+table.getRowMargin()+"px");
				writeCssProperty("."+table._title+"-column-selected", "padding-bottom", ""+table.getRowMargin()+"px");
				writeCssProperty("."+table._title+"-column-selected", "padding-left", ""+table.getColumnModel().getColumnMargin()+"px");
				writeCssProperty("."+table._title+"-column-selected", "padding-right", ""+table.getColumnModel().getColumnMargin()+"px");

				//header
				writeCssProperty("."+table._title+"-TabHeader", "border-width", "1px");
				writeCssProperty("."+table._title+"-TabHeader", "border-style", "SOLID");
				writeCssProperty("."+table._title+"-TabHeader", "border-color", "BLACK");
				writeCssProperty("."+table._title+"-TabHeader", "background-color", "ALICEBLUE");
				writeCssProperty("."+table._title+"-TabHeader", "text-align", "CENTER");
				writeCssProperty("."+table._title+"-TabHeader", "font-weight", "BOLD");
				writeCssProperty("."+table._title+"-TabHeader", "padding", "5px");
				
			
				pw.close();
				fos.close();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

		}

		public static void writeCssProperty(String selector, String property, String newValue){
			pw.append(""+selector+"{"+property+":"+newValue+"}");
			pw.println();
		}

		private static void create_headerTable(Element tableHTML, pTable table)
		{
			int num_colonne = table.getColumnCount();
			boolean flagHeader = false;
			Element trHeader = null;
			for(int k=0; k<num_colonne; k++)
			{
				if(k==0) {
					trHeader = doc.createElement("TR");
					trHeader.setAttribute("id", table._title+"-rowHeader");
					flagHeader= true;
				}
				Element th = doc.createElement("TH");
				th.setAttribute("id", table._title+"-colHeader"+k);
				th.setAttribute("class",  table._title+"-tabHeader");
				String colonnaNome = table.getColumnName(k);
				if(colonnaNome == null) th.appendChild(doc.createTextNode(""));
				else th.appendChild(doc.createTextNode(colonnaNome));
				trHeader.appendChild(th);
			}

			if(flagHeader == true) tableHTML.appendChild(trHeader);
		}

		private static void create_rows(Element tableHTML, pTable table)
		{
			int num_righe = table.getRowCount();
			int num_colonne = table.getColumnCount();
			for(int i=0; i<num_righe; i++)
			{
				Element tr = doc.createElement("TR");
				tr.setAttribute("id", table._title+"-row"+i);
				tr.setAttribute("class",  table._title+"-row");
	
				for(int j=0; j<num_colonne; j++)
				{
					Element td = doc.createElement("TD");
					td.setAttribute("id", table._title+"-col"+i+","+j);
					td.setAttribute("class",  table._title+"-column");
					String str = (String) table.getValueAt(i, j);
					if(str == null) td.appendChild(doc.createTextNode(""));
					else td.appendChild(doc.createTextNode(str));
					tr.appendChild(td);
				}

				tableHTML.appendChild(tr);
			}

		}
	
	public static void writePage(String fl) throws URISyntaxException{
		//individuo i vari insiemi
		Iterator setsIterator = _partition.iterator();
		int id = 0;
		while(setsIterator.hasNext()){
			Set<String> set = (Set<String>) setsIterator.next();
			Element frame = addFrame("frame"+id);
			Iterator setIterator = set.iterator();
			
			while(setIterator.hasNext()){
				String key = (String) setIterator.next();
				Element element = elements.get(key);
				if(element != null){
					frame.appendChild(element);
				}
			}
			//controllo che il frame da aggiungere non sia vuoto
			if(frame.hasChildNodes()){
				frames.put("frame"+id, frame);
				id++;
			}
		}

		//creazione dei frame
		Set<Entry<String, Element>> f = frames.entrySet();
		Iterator i = f.iterator();
		while(i.hasNext()){
			Entry<String, Element> entry = (Entry<String, Element>) i.next();
			body.appendChild(entry.getValue());
		}
		
		addFooter();
		
		//AGGIUNTA DEGLI SCRIPT
		addScript("js/hammer.min.js");
		addScript("js/index.js");
		addScript("js/test.js");
		addScript("js/cordova.js"); 
		addScript("js/phonegap.js"); 
		addScript("js/ionic.bundle.min.js");
		addScript("js/menu/menulaterale.js");
		addScript("js/tableEvent.js");
		TransformerFactory transformerFactory = TransformerFactory.newInstance();
		Transformer transformer;

		try {
			transformer = transformerFactory.newTransformer();
		    transformer.setOutputProperty(OutputKeys.METHOD, "html");
			DOMSource source = new DOMSource(doc);
			StreamResult result = new StreamResult(fl);
			transformer.transform(source, result);
		} catch (TransformerException exception) {
			exception.printStackTrace();
		}
	}
}


