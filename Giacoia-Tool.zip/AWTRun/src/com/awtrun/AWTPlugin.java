package com.awtrun;

import awtcalc2pg.*;
import mini.ListaShopExtended_pawt;
import mini.ListaShop_pawt;

import mini.SwapTeam_pawt;

import org.apache.cordova.CallbackContext;
import org.apache.cordova.CordovaPlugin;
import org.json.JSONObject;
import org.json.JSONArray;
import org.json.JSONException;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import android.webkit.WebView;

public class AWTPlugin extends CordovaPlugin {

	private Object obj;
	private pFrame component;


	public AWTPlugin() {
		
		/*obj = new SwapTeam_pawt();
		component = (pFrame) ((SwapTeam_pawt) obj).getTopComponent();*/
		
		obj = new ListaShop_pawt();
		component = (pFrame) ((ListaShop_pawt) obj).getTopComponent();
		
		/*obj = new ListaShopExtended_pawt();
		component = (pFrame) ((ListaShopExtended_pawt) obj).getTopComponent();*/
		
		
	}

	public boolean execute(String action, JSONArray args,
			CallbackContext callbackContext) throws JSONException {

		try {
			Constants.view = webView;
			Log.d("awtrun", "Plugin action call! : " + action);

			if (action.equals("insert")) {
				JSONObject arg_object = args.getJSONObject(0);
				String id = arg_object.getString("id");
				String value = arg_object.getString("element");
				component.change(id, value);
			} else if (action.equals("fire")) {
				JSONObject arg_object = args.getJSONObject(0);
				String id = arg_object.getString("id");
				component.fire(id);
			} else if (action.equals("fireRow")){
				JSONObject arg_object = args.getJSONObject(0);
				String id = arg_object.getString("id");
				String row = arg_object.getString("row");
				component.fireRow(id, row);
			} else if (action.equals("fireCell")){
				JSONObject arg_object = args.getJSONObject(0);
				String id = arg_object.getString("id");
				String row = arg_object.getString("row");
				String column = arg_object.getString("column");
				component.fireCell(id, row, column);
			} else if (action.equals("insertTable")){
				JSONObject arg_object = args.getJSONObject(0);
				String id = arg_object.getString("id");
				String row = arg_object.getString("row");
				String column = arg_object.getString("column");
				String value = arg_object.getString("value");
				component.change(id, row, column, value);
			}

			return true;

		} catch (Exception e) {
			callbackContext.error(e.getMessage());
			return false;
		}
	}
}
