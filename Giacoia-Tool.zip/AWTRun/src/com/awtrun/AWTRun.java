package com.awtrun;

import java.util.concurrent.ExecutorService;

import org.apache.cordova.CordovaInterface;
import org.apache.cordova.CordovaPlugin;
import org.apache.cordova.CordovaWebView;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.WindowManager;



import android.webkit.WebSettings;

public class AWTRun extends Activity implements CordovaInterface{

	 CordovaWebView cwv;
	 
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_awtrun);
		
		  Log.d("awtrun","AWTRun Started");
	        
	      getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
	        
	      cwv = (CordovaWebView) findViewById(R.id.tutorialView);
	      cwv.loadUrl("file:///android_asset/www/index.html");
	      
	
	   
	     
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.awtrun, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public Activity getActivity() {
		return this;
	}

	@Override
	public ExecutorService getThreadPool() {
		return null;
	}

	@Override
	public Object onMessage(String arg0, Object arg1) {
		Log.d("awtrun","onMessage:"+arg0+","+arg1);
		return null;
	}

	@Override
	public void setActivityResultCallback(CordovaPlugin arg0) {	
	}

	@Override
	public void startActivityForResult(CordovaPlugin arg0, Intent arg1, int arg2) {
	}
}
