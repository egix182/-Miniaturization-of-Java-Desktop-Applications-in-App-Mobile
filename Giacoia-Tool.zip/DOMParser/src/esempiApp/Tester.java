package esempiApp;

import java.net.URISyntaxException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import awtcalc2pg.pComponent;
import awtcalc2pg.pFrame;
import awtcalc2pg.pMenu;
import awtcalc2pg.parserHTML;



public class Tester {

	public static void main(String[] args) throws URISyntaxException {
		
		/*Set<Set<String>> partition = testPartitionSwapTeam();
		SwapTeam_pawt obj = new SwapTeam_pawt();
		pFrame frame = obj.getTopComponent();
		ArrayList<pMenu> menu_bar = frame.getMainBarra();
		parserHTML.createPage("index.html", partition);
		parserHTML.addmenu(menu_bar);
		//parserHTML.addHeader("SwapTeam");
		parserHTML.parse(frame);
		parserHTML.writePage("index.html");*/
		
		
		Set<Set<String>> partition = testPartitionListaShop();
		ListaShop_pawt obj = new ListaShop_pawt();
		pFrame frame = obj.getTopComponent();
		ArrayList<pMenu> menu_bar = frame.getMainBarra();
		parserHTML.createPage("index.html", partition);
		parserHTML.addmenu(menu_bar);
		//parserHTML.addHeader("ListaShop");
		parserHTML.parse(frame);
		parserHTML.writePage("index.html");
		
		/*Set<Set<String>> partition = testPartitionListaShopExtended();
		ListaShopExtended_pawt obj = new ListaShopExtended_pawt();
		pFrame frame = obj.getTopComponent();
		ArrayList<pMenu> menu_bar = frame.getMainBarra();
		parserHTML.createPage("index.html", partition);
		parserHTML.addmenu(menu_bar);
		//parserHTML.addHeader("ListaShopExtended");
		parserHTML.parse(frame);
		parserHTML.writePage("index.html");*/
	}

	private static Set<Set<String>> testPartitionSwapTeam() {
		Set<Set<String>> partition = new HashSet<Set<String>>();
		Set<String> firstSet = new HashSet<String>();
		Set<String> secondSet = new HashSet<String>();
		
		firstSet.add("mainFrame");
		firstSet.add("panelS1");
		firstSet.add("Tabella0");
		firstSet.add(">>");
		firstSet.add("Juventus");
		
		
		
		secondSet.add("panelS2");
		secondSet.add("Tabella1");
		secondSet.add("<<");
		secondSet.add("Milan");
		
		

		
		partition.add(firstSet);
		partition.add(secondSet);
		
		return partition;
	}
	
	private static Set<Set<String>> testPartitionListaShop() {
		Set<Set<String>> partition = new HashSet<Set<String>>();
		Set<String> firstSet = new HashSet<String>();
		Set<String> secondSet = new HashSet<String>();
		
		firstSet.add("mainframe");
		firstSet.add("Aggiungi");
		firstSet.add("Negozio");
		firstSet.add("Costo");
		firstSet.add("Oggetto");
		
		secondSet.add("Rimuovi");
		secondSet.add("Tabella0");

		partition.add(firstSet);
		partition.add(secondSet);
	
		
		return partition;
	}
	
	private static Set<Set<String>> testPartitionListaShopExtended() {
		Set<Set<String>> partition = new HashSet<Set<String>>();
		Set<String> firstSet = new HashSet<String>();
		Set<String> secondSet = new HashSet<String>();
		
		firstSet.add("mainframe");
		firstSet.add("Aggiungi");
		firstSet.add("Luogo");
		firstSet.add("Data");
		firstSet.add("Sconto");
		firstSet.add("Negozio");
		firstSet.add("Costo");
		firstSet.add("Oggetto");
		
		
		secondSet.add("Rimuovi");
		secondSet.add("Tabella0");

		partition.add(firstSet);
		partition.add(secondSet);
	
		
		return partition;
	}
}
