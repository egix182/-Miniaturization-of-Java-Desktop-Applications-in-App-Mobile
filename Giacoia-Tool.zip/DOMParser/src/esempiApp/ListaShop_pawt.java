package esempiApp;

import awtcalc2pg.*;
import table.DefaultTableModel;

public class ListaShop_pawt {

	private pFrame mainFrame;
	private pTable tabella;
	private pTextField oggetto;
	private pTextField costo;
	private pTextField negozio;
	private pButton aggiungi;
	private pButton rimuovi;
	private DefaultTableModel model;
	private pMenuBar barraMenu = new pMenuBar();

	private String[] columnName = {"Oggetto", "Costo", "Negozio"};
	private Object[][] data = { 
			{"Giacca", "60", "Sottotono" },
	};
	
	public ListaShop_pawt()
	{
		model = new DefaultTableModel(data,columnName);
		mainFrame = new pFrame("Java AWT ListaShop");
		tabella = new pTable(model);
		oggetto = new pTextField("Oggetto", 12);
		costo = new pTextField("Costo", 6);
		negozio = new pTextField("Negozio", 12);
		aggiungi = new pButton("Aggiungi");
		rimuovi = new pButton("Rimuovi");
		
		
		
		pPanel panelUp = new pPanel();
		//panelUp.setLayout(new FlowLayout());
		panelUp.add(oggetto);
		panelUp.add(costo);
		panelUp.add(negozio);
		panelUp.add(aggiungi);
		panelUp.add(rimuovi);
		
		/*mainFrame.setLayout(new BorderLayout());
		mainFrame.add(panelUp, BorderLayout.PAGE_START);
		mainFrame.add(tabella, BorderLayout.CENTER);
		mainFrame.setVisible(true);
		mainFrame.pack();*/
		mainFrame.add(panelUp);
		mainFrame.add(tabella);
		mainFrame.setMenuBar(barraMenu);
		model.addTableModelListener(tabella);
		
		rimuovi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] rows = tabella.getSelectedRows();
				for(int i: rows){
					model.removeRow(i);
				}
			}
		});
		
		aggiungi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object[] obj = {oggetto.getText(), costo.getText(), negozio.getText()};
				model.addRow(obj);
			}
		});
	}
	
	public pFrame getTopComponent(){
		return mainFrame;
	}
	
	/*public static void main(String[] args) {
		new ListaShop_pawt();
	}*/
	
}
