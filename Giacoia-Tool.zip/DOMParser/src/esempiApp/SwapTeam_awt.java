package esempiApp;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;

import javax.swing.table.DefaultTableModel;



public class SwapTeam_awt {
	private JFrame mainFrame;
	private JTable table0;
	private JTable table1;
	private DefaultTableModel model0; 
	private DefaultTableModel model1; 
	private JLabel squadra0;
	private JLabel squadra1;
	private JButton s0TOs1;
	private JButton s1TOs0;
	
	public SwapTeam_awt()
	{
		squadra0 = new JLabel("Juventus");
		squadra1 = new JLabel("Milan");
		String[] columnName = {"Nome", "Cognome"};
		Object[][] dataS0 = {
				{"Alessandro", "Del Piero"},
				{"Gianluca", "Zambrotta"},
				{"Gianluigi", "Buffon"},
		};
		Object[][] dataS1 = {
				{"Filippo", "Inzaghi"},
				{"Andrea", "Pirlo"},
				{"Paolo", "Maldini"},
		};
		
		s0TOs1 = new JButton(">>");
		s1TOs0 = new JButton("<<");
			
		mainFrame = new JFrame("Java AWT SwapTeam");
		
		JPanel panelS0 = new JPanel();
		model0 = new DefaultTableModel(dataS0,columnName);
		table0 = new JTable(model0);
		JPanel panelT0 = new JPanel();
		panelT0.setLayout(new BorderLayout());
		panelT0.add(table0.getTableHeader(), BorderLayout.PAGE_START);
		panelT0.add(table0, BorderLayout.CENTER);
		table0.setForeground(Color.WHITE);
		table0.setGridColor(Color.WHITE);
		table0.setBackground(Color.BLACK);
		table0.setRowHeight(60);
		table0.setIntercellSpacing(new Dimension(10,0));
		panelS0.add(squadra0);
		panelS0.add(panelT0);
		panelS0.add(s0TOs1);
		mainFrame.add(panelS0);
		
		JPanel panelS1 = new JPanel();
		model1 = new DefaultTableModel(dataS1,columnName);
		table1 = new JTable(model1);
		JPanel panelT1 = new JPanel();
		panelT1.setLayout(new BorderLayout());
		panelT1.add(table1.getTableHeader(), BorderLayout.PAGE_START);
		panelT1.add(table1, BorderLayout.CENTER);
		table1.setForeground(Color.RED);
		table1.setGridColor(Color.RED);
		table1.setBackground(Color.BLACK);
		table1.setRowHeight(60);
		table1.setIntercellSpacing(new Dimension(10,0));
		panelS1.add(s1TOs0);
		panelS1.add(panelT1);
		panelS1.add(squadra1);
		mainFrame.add(panelS1);
		

		mainFrame.setLayout(new FlowLayout());
		mainFrame.pack();
		mainFrame.setVisible(true);
		
		s0TOs1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] rows = table0.getSelectedRows();
				for(int i: rows){
					Vector v = (Vector) model0.getDataVector().elementAt(i);
					model1.addRow((Vector)v.clone());
					model0.removeRow(i);
				}
			}
		});
		
		s1TOs0.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] rows = table1.getSelectedRows();
				for(int i: rows){
					Vector v = (Vector) model1.getDataVector().elementAt(i);
					model0.addRow((Vector)v.clone());
					model1.removeRow(i);
				}
			}
		});
	}
	

	public static void main(String[] arg)
	{
		new SwapTeam_awt();
	}

}
