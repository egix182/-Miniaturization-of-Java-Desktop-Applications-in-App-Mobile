package esempiApp;

import awtcalc2pg.*;
import table.DefaultTableModel;

public class ListaShopExtended_pawt {

	private pFrame mainFrame;
	private pTable tabella;
	private pTextField oggetto;
	private pTextField costo;
	private pTextField negozio;
	private pTextField sconto;
	private pTextField dataAcquisto;
	private pTextField luogo;
	private pButton aggiungi;
	private pButton rimuovi;
	private DefaultTableModel model;
	private pMenuBar barraMenu = new pMenuBar();

	private String[] columnName = {"Oggetto", "Costo", "Negozio", "Percentuale di Sconto","Data", "Luogo"};
	private Object[][] data = { 
			{"Giacca", "60", "Sottotono", "Nessuna", "14/06/2017", "Battipaglia"},
			{"Maglione", "20", "Belli&Comodi", "20%", "22/06/2017", "Nocera"},
			{"Scarpe", "100", "Calzature Giordano", "10%","28/06/2017", "Nemoli"},

	};
	
	public ListaShopExtended_pawt()
	{
		model = new DefaultTableModel(data,columnName);
		mainFrame = new pFrame("Java AWT ListaShop");
		tabella = new pTable(model);
		oggetto = new pTextField("Oggetto", 12);
		costo = new pTextField("Costo", 6);
		negozio = new pTextField("Negozio", 12);
		sconto = new pTextField("Sconto", 6);
		dataAcquisto = new pTextField("Data", 10);
		luogo = new pTextField("Negozio", 12);
		aggiungi = new pButton("Aggiungi");
		rimuovi = new pButton("Rimuovi");
		
		pPanel panelUp = new pPanel();
		panelUp.add(oggetto);
		panelUp.add(costo);
		panelUp.add(negozio);
		panelUp.add(sconto);
		panelUp.add(dataAcquisto);
		panelUp.add(luogo);
		panelUp.add(aggiungi);
		panelUp.add(rimuovi);
		
		mainFrame.add(panelUp);
		mainFrame.add(tabella);
		mainFrame.setMenuBar(barraMenu);
		model.addTableModelListener(tabella);
		
		rimuovi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				int[] rows = tabella.getSelectedRows();
				for(int i: rows){
					model.removeRow(i);
				}
			}
		});
		
		aggiungi.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object[] obj = {oggetto.getText(), costo.getText(), negozio.getText()};
				model.addRow(obj);
			}
		});
	}
	
	public pFrame getTopComponent(){
		return mainFrame;
	}
	
	/*public static void main(String[] args) {
		new ListaShop_pawt();
	}*/
	
}
