package awtcalc2pg;

public class pTextField extends pComponent {
	String _value = "";
	Integer _size;

    public pTextField(String title, Integer size){
		_title = title;
		_size = size;
	}
    
    public String getText() {
		return _value;	
	}
    
	public void setText(String value) {
		/*
		if(!value.equals(_value)) {
			_value = value;
				try {
					CordovaWebView wv = Constants.view;
					if(wv != null){
						wv.sendJavascript("app.setta('"+_title+"','"+_value+"')");
				//Log.d("sono in if", "appsetta : " + _title);
						}	
				} catch(Exception e) {}
			}	
		
		 */
	}
	
    public void setRoot(pComponent root){
        this._root = root;
    }
    
    public void create(){
		parserHTML.addTextField(_size, _title);
	}
}
