package awtcalc2pg;

import java.util.ArrayList;

public class pPanel extends pComponent{
	pFrame frame;
	
	public pPanel(){
		frame = new pFrame("");
		_title = "Panel"+Math.random();
	}
	
	public void add(pComponent comp){
		frame.add(comp);
	}
	
	 public ArrayList<pComponent> getComponents(){
		 return frame.getComponents();
	 }
}
